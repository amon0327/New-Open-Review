import React from 'react';
import { motion } from 'framer-motion';
import { Paper, Typography } from '@mui/material';

export default function CreatePagePlaceholder() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      <Paper
        sx={{
          p: 4,
          height: 'calc(100vh - 120px)',
          borderRadius: 3,
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
          color: 'white'
        }}
      >
        <Typography variant="h4" color="inherit">
          Create Content Container
        </Typography>
      </Paper>
    </motion.div>
  );
}